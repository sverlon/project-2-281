// Project Identifier: 9504853406CBAC39EE89AA3AD238AA12CA198043

#include "Game.h"
using namespace std;

int main(int argc, char **argv)
{
    Game niraqToTheBance(argc, argv);

    niraqToTheBance.playGame();

    return 0;
}